package pregunta4;

public enum Tipo {
	libro,
	novela,
	ensayo;
}
