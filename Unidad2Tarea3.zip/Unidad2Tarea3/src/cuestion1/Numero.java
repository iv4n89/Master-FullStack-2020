package cuestion1;

public class Numero {
    private final Double n;

    public Numero(Double n) {
        this.n = n;
    }

    public Double getNumero() {
        return n;
    }
}
