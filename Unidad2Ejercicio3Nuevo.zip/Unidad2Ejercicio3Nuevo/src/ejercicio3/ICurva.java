package ejercicio3;

public interface ICurva extends IFigura{
    double calculateArea();
}
