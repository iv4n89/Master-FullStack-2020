package ejercicio3;

public interface IFigura {
    String getColor();
    double[] getPosition();
}
