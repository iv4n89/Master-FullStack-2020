module Tarea6 {
}