package cuestion1;

public interface Expresion {
    public Double getValor();
    public String getEcuacion();
}
