package main;

import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class FechaUtils {

	public static String convertirFechaAString(Date date) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		if(date==null) throw new RuntimeException();
		
		return sdf.format(date);
	}
	
	public static Date obtenerDate(int anio, int mes, int dia) {
		
		/*
		Calendar cal = Calendar.getInstance();
		//cal.set(anio, mes, dia);
		cal.set(anio, mes-1, dia);
		
		return cal.getTime();
		*/
		
		/*
		 * Este m�todo nos permite situarnos en la hora 0 de un d�a concreto
		 * y convertirlo a milisegundos, para luego crear un objeto Date con
		 * el resultado.
		 * */
		try {
			LocalDate ld = LocalDate.of(anio, mes, dia);
			return Date.from(ld.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
		}catch(DateTimeException ex) {
			ex.fillInStackTrace();
			return null;
		}
		
	}
	
	public static boolean validarDatosFecha(int anio, int mes, int dia) {
		
		try {
			LocalDate.of(anio, mes, dia);
			return true;
		} catch(DateTimeException ex) {
			return false;
		}
		
	}
}
