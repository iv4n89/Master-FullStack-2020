package Unidad3.Terea3;
/*
Put header here


 */

import java.net.URL;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class FXMLController implements Initializable {
    
    @FXML
    private Label lblOut,labelOut1,labelOut2,labelOut3,labelOut4,labelSundays;
    @FXML
    private TextField textDate1,textDate2,textDate3,textFormat,textYear,textMonth;
    
    @FXML
    private void btnClickAction(ActionEvent event) {
        lblOut.setText("Hello World!");
    }
    
    @FXML
    private void stringToDate() {
    	String format=textFormat.getText();
    	Fechas fechas=new Fechas(format);
    	Date dateAux=fechas.convertirStringADate(textDate1.getText());
    	labelOut1.setText(dateAux.toString());
    	labelOut2.setText(fechas.convertirDateAString(dateAux));
    	
    }
    
    @FXML
    private void timeBetween() {
    	Fechas fecha=new Fechas("dd/MM/yyyy");
    	Date fecha1=fecha.convertirStringADate(textDate2.getText());
    	Date fecha2=fecha.convertirStringADate(textDate3.getText());
    	labelOut4.setText(fecha.tiempoEntre2Fechas(fecha1, fecha2));
    }
    
    @FXML
    private void getSundays() {
    	int years=Integer.valueOf(textYear.getText());
    	int months=Integer.valueOf(textMonth.getText());
    	int days=java.time.Month.of(months).maxLength();
    	int sundays=0;
    	int i=1;
    	LocalDate d1=LocalDate.of(years, months, 1);
    	while(i<days) {
    		if(d1.getDayOfWeek()==java.time.DayOfWeek.SUNDAY) {
    			sundays++;
    		}
    		i++;
    		d1=d1.plusDays(1);
    	}
    	labelSundays.setText("El mes de "+d1.getMonth().name()+" del año "+d1.getYear()+" tiene "+sundays+" domingos");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
}
