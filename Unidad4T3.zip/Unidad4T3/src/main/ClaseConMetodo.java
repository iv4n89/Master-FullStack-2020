package main;

public class ClaseConMetodo {

	@NoNulls
	public int sumar(Integer n1,Integer n2,Integer n3) {

		return n1+n2+n3;
	}
	
}
