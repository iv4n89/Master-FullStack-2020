package ejercicio3;

public interface IPoligonal extends IFigura{
    int getFaces();
    double getCenterOfObject();
    double getDistanceFromCenter();
}
