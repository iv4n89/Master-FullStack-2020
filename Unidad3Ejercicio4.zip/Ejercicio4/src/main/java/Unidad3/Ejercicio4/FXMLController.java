package Unidad3.Ejercicio4;
/*
Put header here


 */

import java.awt.Color;
import java.awt.Font;
import java.beans.EventHandler;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.swing.text.DateFormatter;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.paint.Paint;

public class FXMLController implements Initializable {
	
	private static final String PATH_SAVE_CLOSE=System.getProperty("user.home") +"/app.config";
	private static final String PATH_PREFERENCES=System.getProperty("user.home") + "/preferences.properties";
	private static Properties preferences;
    
    @FXML
    private Label lblOut,formattedText;
    
    private LocalDateTime closingTime;
    
    @FXML
    private void btnClickAction(ActionEvent event) throws IOException {
    	closingTime= LocalDateTime.now();
    	
    	Properties saveCloseTime = new Properties();
    	saveCloseTime.put("closeTime", "La ultima vez que se cerro fue en: "+closingTime.format(DateTimeFormatter.ofPattern("dd/MM/yyyy - HH:mm:ss")).toString());
    	saveCloseTime.store(new FileWriter(PATH_SAVE_CLOSE),null);
        System.exit(0);
    }
    
    @FXML
    private void onChangeTextColor(ActionEvent e) throws IOException {
    	String color=e.getSource().toString().subSequence(2+e.getSource().toString().indexOf('='), e.getSource().toString().indexOf(',')).toString();
    	preferences.setProperty("color", color);
    	preferences.store(new FileWriter(PATH_PREFERENCES), null);
    	formattedText.setTextFill(Paint.valueOf(color));
    }
    
    @FXML
    private void onChangeTextFont(ActionEvent e) throws IOException {
    	String font=e.getSource().toString().subSequence(2+e.getSource().toString().indexOf('='), e.getSource().toString().indexOf(',')).toString();
    	preferences.setProperty("font", font);
    	preferences.store(new FileWriter(PATH_PREFERENCES), null);
    	formattedText.setFont(javafx.scene.text.Font.font(font));
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    	preferences=readSettingsFormat(PATH_PREFERENCES, new String[] {"color","font"});
    	readSettingsTime(PATH_SAVE_CLOSE, "closeTime");
    	Paint color=Paint.valueOf(preferences.getProperty("color"));
		javafx.scene.text.Font font=javafx.scene.text.Font.font(preferences.getProperty("font"));
		formattedText.setTextFill(color);
		formattedText.setFont(font);
    }
    
    private void readSettingsTime(String path, String key) {
    	Properties p = new Properties();
    	try {
			p.load(new FileInputStream(path));
			String aux= p.getProperty(key);
			lblOut.setText(aux);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			try {
				p.store(new FileWriter(path), null);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
    }
    
    private Properties readSettingsFormat(String path, String...key) {
    	Properties p = new Properties();
    	try {
			p.load(new FileInputStream(path));
			return p;
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			try {
				p.setProperty(key[0], "RED");
				p.setProperty(key[1], "Arial");
				p.store(new FileWriter(path), null);
				return p;
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				return null;
			}
		}
    }
}
