package ejercicio2;

public interface IFusible {
    void encender();
    void apagar();
    boolean isEncendido();
}
