package ejercicio3;

public interface IRedonda extends IFigura, ICurva{
    
}
