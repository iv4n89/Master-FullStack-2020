package cuestion1;

import java.util.ArrayList;

public class ListaArchivos<T extends Archivo> extends ArrayList<T>{

}
